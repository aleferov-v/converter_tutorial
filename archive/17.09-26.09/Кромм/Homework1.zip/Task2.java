public class Task2 {
    public static void main(String[] args) {
        // Создание массива

        int[] arr = {9, 18, 6, 3, 19, 30};
        // Считаем среднее арифметическое
        int sum = 0;
        for (int i=0; i < 6; i++) {
            sum = sum + arr[i];
        }
        System.out.println("Среднее арифметическое");
        System.out.println(sum/6);
    }
}
