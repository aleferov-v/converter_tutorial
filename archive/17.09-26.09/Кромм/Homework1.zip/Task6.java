
import java.util.Arrays;
import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите размер массива:");
        int N = in.nextInt();
        int[] arr = new int[N];

        for (int i = 0; i < N; i++) {
            arr[i] = (int) Math.round(Math.random()*30-15);
        }

        System.out.println("Первоначальный массив:");
        System.out.println(Arrays.toString(arr));

        int min = arr[0];
        int min_index = 0;

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
                min_index = i;
            }
        }

        int max = arr[0];
        int max_index = 0;

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
                max_index = i;
            }
        }

        arr[max_index] = min;
        arr[min_index] = max;

        System.out.println("Требуемый массив:");
        System.out.println(Arrays.toString(arr));

    }
}
