public class Task3 {
    public static void main(String[] args) {
            int[] arr = new int[10]; // Созднаие массива
            int a = 1;
            int i = 0;

            while (i <= 9) {
                arr[i] = a;
                a+=2;
                i++;
            }

            System.out.println("Первые 10 нечетных чисел:");
            for (int j = 0; j < (arr.length); j++) {
                System.out.print(arr[j] + ", ");
            }
    }
}
