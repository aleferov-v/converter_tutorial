import java.util.Arrays;
import java.util.Scanner;
public class Task1 {
    public static void main(String[] args) {
        // Создание массива

        int[] arr = {9, 18, 6, 3, 19, 30};

        // Вывод элементов, делящихся на 3 и 6

        System.out.println("Числа, делящиеся на 3 и 6:");

        for (int i = 0; i < arr.length; i++) {
            if ((arr[i] % 3 == 0) && (arr[i] % 6 == 0)) {
                System.out.print(arr[i] + " ");
            }
        }
    }
}
