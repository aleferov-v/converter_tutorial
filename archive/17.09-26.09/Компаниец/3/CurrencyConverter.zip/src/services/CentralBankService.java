package services;

import conversion.Currency;
import exceptions.ConverterException;


public class CentralBankService {

    //Singleton implementation
    private static CentralBankService CentralBankServiceInstance = new CentralBankService();

    public static CentralBankService getInstance() { return CentralBankServiceInstance; }

    private CentralBankService() {
    }

    //Currency rates
    private static final double USD_RATE = 67.01;
    private static final double EUR_RATE = 78.36;
    private static final double GBP_RATE = 88.23;
    private static final double RUB_RATE = 1;

    //Get exchange rate for given currency
    public double getCurrentRate (Currency currency) throws ConverterException {

        double currentRate = 1;

        switch (currency) {
            case USD:
                currentRate = USD_RATE;
                break;
            case EUR:
                currentRate = EUR_RATE;
                break;
            case GBP:
                currentRate = GBP_RATE;
                break;
            case RUB:
                currentRate = RUB_RATE;
                break;
            default:
                throw new ConverterException();
        }

        return currentRate;

    }
}
