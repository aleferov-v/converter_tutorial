package conversion;

public enum Currency {

    USD("U.S. Dollar"),
    EUR("Euro"),
    GBP("U.K. Pound"),
    RUB("Russian rouble");

    Currency(String description) {
    }

}
