package conversion.datasource;

import conversion.ConvertData;

public interface IDataSource {
    public ConvertData getConvertData();
}
