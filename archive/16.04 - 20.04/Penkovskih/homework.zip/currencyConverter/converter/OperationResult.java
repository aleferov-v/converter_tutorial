package com.company.currencyConverter.converter;

public enum OperationResult {

    SUCCESS("Выполнено успешно"), ERROR("Ошибка в ходе выполнения");

    OperationResult(String result) {

    }
}
