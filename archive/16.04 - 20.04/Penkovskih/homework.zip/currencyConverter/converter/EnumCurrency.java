package com.company.currencyConverter.converter;

public enum EnumCurrency {
    USD("Доллар СШР"), RUB("Рубль России");

    EnumCurrency(String currency) {

    }
}
