package com.company.currencyConverter.interfaces;

import com.company.currencyConverter.converter.ConvertionResult;



public interface IConverter {
    ConvertionResult convert();
}
