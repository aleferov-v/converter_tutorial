package exception;

public class ConvertionException extends Exception {
    public ConvertionException(String msg) {
        super(msg);
    }
}
