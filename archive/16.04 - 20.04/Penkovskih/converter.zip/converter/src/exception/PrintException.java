package exception;

public class PrintException extends Exception {
    public PrintException(String message) {
        super(message);
    }
}
