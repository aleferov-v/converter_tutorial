package person;

import java.util.UUID;

public  abstract class Person {
   public static UUID id;

}
