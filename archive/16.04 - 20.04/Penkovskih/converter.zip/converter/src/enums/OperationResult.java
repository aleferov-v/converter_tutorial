package enums;

public enum OperationResult {
    SUCCESS, ERROR
}
