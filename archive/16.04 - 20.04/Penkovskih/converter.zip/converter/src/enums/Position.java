package enums;

public enum Position {

    EMPLOYEE, STUDENT

}
