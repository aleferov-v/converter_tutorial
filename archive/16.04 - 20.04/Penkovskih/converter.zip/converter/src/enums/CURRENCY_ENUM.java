package enums;

public enum CURRENCY_ENUM {
    USD, RUB, EUR
}
