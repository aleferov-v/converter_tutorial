package interfaces;

public interface EmployeeFactory {
    Employee getEmployeeFromFactory(String employee);
}
