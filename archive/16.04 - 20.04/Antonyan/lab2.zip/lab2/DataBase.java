package lab2;

public class DataBase {

    public final static String[][] CLIENTS = {
            {"1", "2"},
            {"ИВАНОВ И.П.", "ПЕТРОВ И.В."},
            {"true", "false"}
    };

    public static final String[][] CASSIER = {
            {"1", "2"},
            {"РАППОПОРТ И.Г.", "МИХЕЛЬСОН П.Р."}
    };

    static final String[][] COURSE = {
            {"USD/EUR", "USD/RUB", "EUR/USD", "EUR/RUB", "RUB/USD", "RUB/EUR"},
            {"0.81", "61.63", "1.24", "76.15", "0.016", "0.013"}
    };

}
