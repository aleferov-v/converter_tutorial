package lab2;

public interface IDataSource {

    ConvertData getConvertData();
}
