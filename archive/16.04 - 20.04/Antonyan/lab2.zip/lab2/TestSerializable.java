package lab2;

public interface TestSerializable {
}
