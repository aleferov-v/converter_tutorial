package lab2;

public class FileDataSource implements IDataSource {
}
