package stubs;

import currency.CurrencyCode;
import data.CourseRate;

import java.util.HashMap;
import java.util.Map;

public class CourseRateListStub {
    /**
     * Валютные котировки на сегодня
     */


    public Map<CurrencyCode, CourseRate> createStub() {

        Map<CurrencyCode, CourseRate> stub = new HashMap<CurrencyCode, CourseRate>();

        for (CurrencyCode code : CurrencyCode.values()) {
            if (code == CurrencyCode.USD) {
                stub.put(code, new CourseRate(60.00, 62.00, 1));
            } else if (code == CurrencyCode.EUR) {
                stub.put(code, new CourseRate(70.00, 72.00, 1));
            } else {
                stub.put(code, new CourseRate(50.00, 52.00, 10));
            }

        }

        return stub;
    }
}







