package system;

import converter.Converter;
import converter.ConvertionResult;
import converter.OperationStatus;
import converter.ResultCode;
import data.ClientExtractProcessing;
import data.FileDataSource;
import person.CheckingClient;
import person.Client;
import stubs.InitRequestProcessing;

/**
 * Главный класс программы.
 * Создание заявки (request)
 * Создание и получение клиента. Содание и получение оператора.
 * Считывание входных данных
 * Вызов конвертера converter.Converter()
 */
public class Session {

    /**
     * Идентификатор клиента
     */
    static private String id;

    static private OperationStatus checkingClient;

    static private ConvertionResult result = new ConvertionResult();

    public static void main(String[] args) {

        id = "0001";


//        MoneyType currencyIn;
//
//        MoneyType currencyOut;
        Printer printer = new Printer();

        try {
            Client client = new ClientExtractProcessing().createClientDataStub();

            checkingClient = new CheckingClient(client).checkClientDul();

            if (checkingClient.getCode() == ResultCode.ERROR) {

                result.setCode(checkingClient.getCode());
                throw new Exception(checkingClient.getMessage());


            } else {
                result.setCode(checkingClient.getCode());
            }
        } catch (Exception e) {
            printer.print(result);


        }

        ConverterRequest request = new InitRequestProcessing().initRequestStub(id);  //инициализация заявки через stub


        //request.setCurrencyIn(CurrencyCode.RUB, 100.00);

        Converter converter = new Converter(request);
        try {
            result = converter.convert();
        } catch (NoDataException e) {
            e.printStackTrace();

        }

        printer.print(result);


        /**
         * debug parcer FileDataSource
         */
        /
        try {
            new FileDataSource().createData("/home/h1ddenhyde/workspace/Converter/textFiles/courseRate_today.txt");
        } catch (Exception e){
            System.out.println("exception");
        }
    }
}
