package data;

import converter.OperationStatus;
import converter.ResultCode;
import currency.CurrencyCode;
import system.NoDataException;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class FileDataSource extends DataSource {

    /**
     * Считываение данных из файла
     */


    @Override
    public String createData(String path) throws Exception {
        if (path == null) throw new NoDataException("Невозможно получить данные: не указан путь");

        FileReader reader = new FileReader(path);
        Scanner scanner = new Scanner(reader);
        Map<CurrencyCode, CourseRate> map = new HashMap<CurrencyCode, CourseRate>();

        String data = "";

        while (scanner.hasNextLine()) {

            data = (scanner.nextLine()); //type buy sell rate
            String buy = data.substring(0, data.indexOf(",")).trim();
            data = data.substring(data.indexOf(",")+1, data.length());
            String sell = data.substring(0, data.indexOf(",")).trim();
            data = data.substring(data.indexOf(",")+1, data.length());
            String rate = data.substring(0, data.indexOf(",")).trim();
            data = data.substring(data.indexOf(",")+1, data.length());

          //  ResultCode.valueOf();

            //map.put();

        }
        reader.close();

        return data;
    }
}
