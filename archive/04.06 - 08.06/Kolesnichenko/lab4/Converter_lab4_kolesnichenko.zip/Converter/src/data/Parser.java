package data;

import java.util.Map;

public interface Parser {


    Map parse(String data) throws Exception;
}
