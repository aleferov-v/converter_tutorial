package data;


import person.Client;
import stubs.ClientStub;

public class ClientExtractProcessing {

    public Client createClientDataStub() {
        Client stub = new ClientStub();


        return stub;
    }
}
