package stubs;

public interface ICourseReciever {

    boolean load();

}
