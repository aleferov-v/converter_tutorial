package converter;

public interface IConverter {
    OperationStatus convert() throws Exception;
}
