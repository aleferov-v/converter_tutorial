package converter;

public enum ResultCode {
    SUCCESS, ERROR
}

