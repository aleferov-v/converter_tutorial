public class Session {
    /*
     * Главный класс программы.
     * Создание заявки (request)
     * Создание и получение клиента. Содание и получение оператора.
     * Считывание входных данных
     * Вызов конвертера Converter()
     *
     * */
    public static void main(String[] args) {

        Client client = new ClientStub();
        Operator operator = new Operator();
        ConverterRequest request = new ConverterRequest(client);

        request.setCurrencyIn(CurrencyType.RUB, 100.00);
        Converter converter = new Converter(request);
        request.setResult(converter.convert());
        new Printer(request);
    }
}
