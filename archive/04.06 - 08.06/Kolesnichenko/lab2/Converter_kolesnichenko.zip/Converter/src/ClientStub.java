public class ClientStub extends Client {
    ClientStub(){

        this.dul.setSeria("1111");
        this.dul.setNumber("000000");
        this.dul.setBeginDate("29.01.2000");
        this.setFirstName("Иван");
        this.setSecondName("Иванович");
        this.setSurname("Иванов");
    }

}
