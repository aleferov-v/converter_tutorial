//import static CurrencyDataBase.useReference;
/*
 *Не получилось выполнить статический импорт
 */

public class Converter implements IConverter {
    ConverterRequest request;

    Converter(ConverterRequest request){
        this.request = request;
        }


    @Override
    public ConvertionResult convert() {
        ConvertionResult result;
        if (checkClientData(request.getClient())){

            System.out.println("Клиент есть"); //для проверки
            result = new ConvertionResult(OperationResult.SUCCESS, "");
        } else {
            System.out.println("Ошибка");
            result = new ConvertionResult(OperationResult.ERROR, "Нет данных (ДУЛ)" );
        }

        request.currencyOut= CurrencyDataBase.useReference(request.currencyIn,request.currencyOut.getType() );//Обращение к справочнику без логики

        return result;
    }
    public boolean checkClientData(Client client) {
        /*Проверяет, есть ли у клиента документ
        * */
        return (client.getDul() != null);
           }

    }


