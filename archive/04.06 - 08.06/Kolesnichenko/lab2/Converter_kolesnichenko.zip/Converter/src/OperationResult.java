public enum OperationResult {
    SUCCESS, ERROR
}

