public interface IConverter {
    ConvertionResult convert();
}
