package operation;

import person.Person;

public class Operator extends Person {
    /*
     *Сшитый код типа 9038/113
     */

    private String BranchCode;

    public String getBranchCode() {
        return BranchCode;
    }

    public void setBranchCode(String branchCode) {
        BranchCode = branchCode;
    }
}
