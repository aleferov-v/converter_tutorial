package operation;

public enum OperationResult {
    SUCCESS, ERROR
}

