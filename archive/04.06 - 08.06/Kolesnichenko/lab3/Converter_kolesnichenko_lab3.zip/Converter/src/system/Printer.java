package system;
import converter.ResultCode;
import person.Client;

public class Printer{
    Printer(ConverterRequest request){

        System.out.println("Результат операции: "+
                (request.getResult().getCode()== ResultCode.SUCCESS?"УСПЕШНО":"ОШИБКА"));
        if (request.getResult().getMessage()!=""){
        System.out.println("Описание: "+request.getResult().getMessage());

        }

    }

    Printer (Client client){
        System.out.println("____________________________");
        System.out.println("Данные клиента: ");
        System.out.println("ФИО: "+client.getFirstName()+" "+client.getSecondName()+" "
        + client.getSurname());
    }
}
