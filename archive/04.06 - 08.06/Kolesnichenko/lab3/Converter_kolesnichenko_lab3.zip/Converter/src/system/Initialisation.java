package system;

public class Initialisation {

}
