package system;

public class Reader {
}
