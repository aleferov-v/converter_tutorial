package converter;

import currency.CurrencyCode;
import currency.MoneyType;
import database.*;
import system.*;

public class Converter implements IConverter {


    /**
     * Заявка, с которой сессия вызывает конвертер
     */
    //private ConverterRequest request;

    /**
     * Валюта клиента, которую он хочет обменять
     */

    private MoneyType currencyIn;

    /**
     * Валюта, которую нужно выдать клиенту
     */

    private MoneyType currencyOut;


    public Converter(ConverterRequest request) {

        this.currencyIn = request.currencyIn;
        this.currencyOut = request.currencyOut;
    }

    public Converter(MoneyType currencyIn, CurrencyCode code) {
        this.currencyIn = currencyIn;
        this.currencyOut.setType(code);
    }

    /**
     *
     *
     */


    @Override
    public ConvertionResult convert() {

        ConvertionResult result = new ConvertionResult();

        if (currencyIn.getCourseRate() == null || currencyOut.getCourseRate() == null) {


        }
        CourseRate currInRate = new CourseRate();
        if (currencyOut != null) {
            currInRate = this.currencyIn.getCourseRate();
        }

        CourseRate currOutRate = new CourseRate();
        if (currencyOut != null) {
            currOutRate = this.currencyOut.getCourseRate();
        }


        if (currencyIn.getType() == CurrencyCode.RUB) {
            /*
             * Покупка: клиент покупает валюту "CurrencyOut" на рубли, которые принес
             *
             *outB = inB/sell/rate
             * */
            currencyOut.setValue(currencyIn.getValue() / currOutRate.getSellPrice() / currOutRate.getRate());

        } else if (currencyIn.getType() != CurrencyCode.RUB && currencyOut.getType() == CurrencyCode.RUB) {
            /*
             * Продажа: клиент продает валюту "CurrencyIn", CurrencyOut - рубли
             * outS = inS*buy/rate
             */
            currencyOut.setValue(currencyIn.getValue() * currOutRate.getSellPrice() / currOutRate.getRate());
        } else {
            /*Конверсия(принес определенную сумму)
             * in*buyIn/sellOut/rateIn*rateOut
             */
            double cross = currInRate.getBuyPrice() / currOutRate.getSellPrice();
            currencyOut.setValue(currencyIn.getValue() * cross / currInRate.getRate() * currOutRate.getRate());
        }

        return result;
    }


//    public ConverterRequest getRequest() {
//        return request;
//    }
//
//    public void setRequest(ConverterRequest request) {
//        this.request = request;
//    }

    public MoneyType getCurrencyIn() {
        return currencyIn;
    }

    public void setCurrencyIn(MoneyType currencyIn) {
        this.currencyIn = currencyIn;
    }

    public MoneyType getCurrencyOut() {
        return currencyOut;
    }

    public void setCurrencyOut(MoneyType currencyOut) {
        this.currencyOut = currencyOut;
    }

}


