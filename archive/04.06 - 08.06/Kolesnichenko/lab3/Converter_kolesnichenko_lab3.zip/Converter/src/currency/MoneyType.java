package currency;

import database.CourseRate;

public class MoneyType {
    /**
     * Валютный тип для конвертера: код валюты и значение
     */

    private CurrencyCode type;

    /**
     * Значение валюты
     */

    private double value;

    /**
     * Обменный курс валюты на сегодня
     */

    private CourseRate courseRate;

    public MoneyType(CurrencyCode type, double value) {
        this.type = type;
        this.value = value;

    }

    public MoneyType() {

    }

    public CurrencyCode getType() {
        return type;
    }

    public void setType(CurrencyCode type) {
        this.type = type;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public CourseRate getCourseRate() {
        return courseRate;
    }

    public void setCourseRate(CourseRate courseRate) {
        this.courseRate = courseRate;
    }
}
