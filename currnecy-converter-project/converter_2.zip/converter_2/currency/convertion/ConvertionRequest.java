package currency.convertion;

import currency.services.Utils;

import java.util.UUID;

/**
 * Заявка на конвертацию валюты
 */
public class ConvertionRequest {

    /**
     * Счетчик заявок. Используется для демонстрации поведения статических полей в классе {@link currency.example.StaticExample}
     */
    private static int counter;

    /**
     * Из какой валюты и какая сумма конвертируется
     */
    private Money from;
    /**
     * В какую валюту происходит конвертация
     */
    private Currency to;
    /**
     * Текущий курс исходной валюты
     */
    private double fromRate;
    /**
     * Текущий курс целевой валюты
     */
    private double toRate;

    public ConvertionRequest(Money from, Currency to, double fromRate, double toRate) {
        this.from = from;
        this.to = to;
        this.fromRate = fromRate;
        this.toRate = toRate;
        this.counter++;
    }

    public Money getFrom() {
        return from;
    }

    public Currency getTo() {
        return to;
    }

    public double getFromRate() {
        return fromRate;
    }

    public double getToRate() {
        return toRate;
    }

    public static int getCounter() {
        return counter;
    }

}
