package currency.exceptions;

public class ConverterException extends Throwable {
    public ConverterException() {
        super("Ошибка конвертации");
    }
}
