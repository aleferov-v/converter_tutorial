package currency;

import currency.convertion.ConvertData;
import currency.convertion.ConvertionResult;
import currency.convertion.Currency;
import currency.convertion.Money;
import currency.convertion.convertors.CurrencyConverter;
import currency.convertion.datasource.IDataSource;
import currency.convertion.datasource.ProgrammDataSource;
import currency.person.Client;
import currency.person.DUL;
import currency.person.Operator;
import currency.services.ManagmentService;
import currency.services.Printer;
import currency.services.Utils;

/**
 * Основной класс программы
 */
public class Converter {

    /**
     * Конвертер
     */
    private CurrencyConverter converter;
    /**
     * Принтер для печати резальтата
     */
    private Printer printer;
    /**
     * Сервис по работе с персоналом
     */
    private ManagmentService managmentService;

    public Converter() {
        this.converter = new CurrencyConverter();
        this.printer = new Printer();
        this.managmentService = new ManagmentService();
    }

    /**
     * Метод выполняет конвертацию
     */
    public void run() {
        Operator operator = managmentService.getTodayOperator();

        IDataSource dataSource = new ProgrammDataSource();
        ConvertData dataSourceConvertData = dataSource.getConvertData();

        ConvertionResult convertionResult = converter.convert(dataSourceConvertData, operator);
        printer.print(convertionResult);
    }
}
