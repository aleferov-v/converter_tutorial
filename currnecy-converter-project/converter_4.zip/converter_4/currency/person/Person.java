package currency.person;

/**
 * Абстрактный класс, представляющий некую личность. Ей может быть как клиент, так и работник банка, так как у каждой
 * личности есть имя
 */
public abstract class Person {

    /**
     * Имя
     */
    protected String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
