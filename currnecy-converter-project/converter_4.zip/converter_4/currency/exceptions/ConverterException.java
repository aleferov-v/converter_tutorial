package currency.exceptions;

public class ConverterException extends Throwable {

    public ConverterException() {
        this("Ошибка конвертации");
    }

    public ConverterException(String message) {
        super(message);
    }
}
