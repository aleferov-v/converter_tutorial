package currency.services;

import currency.convertion.Currency;
import currency.exceptions.ConverterException;

import java.util.HashMap;
import java.util.Map;

/**
 * Сервис, имитирующий работу с текущими ставками центробанка относительно валют
 */
public class CentralBankService {

    private static Map<Currency, Double> rates = new HashMap<>();
    static {
        rates.put(Currency.USD, 56.80);
        rates.put(Currency.EUR, 70.53);
        rates.put(Currency.RUB, 1.0);
    }
    /**
     * Единственный экземпляр сервиса работы с центральным банком
     */
    public static CentralBankService instance;

    /**
     * Метод получения инстанса (экземпляра) сервиса
     *
     * @return сервис работы с центральным банком
     */
    public static CentralBankService getInstance() {
        if (instance == null) {
            instance = new CentralBankService();
        }
        return instance;
    }

    /**
     * Получить текущую ставку для валюты. Если ни то ни другое не выбрано, то текущая ставка будет 1, т.е. курс 1 к 1
     *
     * @param currency - валюта
     * @return текущая ставка
     */
    public double getCurrentRate(Currency currency) throws ConverterException {
        Double result = rates.get(currency);
        if (result == null) {
            throw new ConverterException("Не удалось получить курс для валюты: " + currency.getDescription());
        }
        return result;
    }


}
