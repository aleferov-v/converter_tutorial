package currency.convertion.convertors;

import currency.person.Client;
import currency.convertion.*;
import currency.person.Operator;
import currency.services.Utils;

/**
 * Класс, реализующий интерфейс конвертации валют
 */
public class CurrencyConverter implements ICurrencyConverter {

    @Override
    public ConvertionResult convert(ConvertData data, Operator operator) {
        ConvertionResult convertionResult;
        Client client = data.getClient();
        if (operator.check(client)) {
            ConvertionRequest request = operator.createRequest(data);
            double result = (request.getFrom().getAmount() * request.getFromRate()) / request.getToRate();
            Money resultMoney = new Money(request.getTo(), result);
            Money from = request.getFrom();
            ConvertionStatus convertionStatus = new ConvertionStatus(ConvertionStatus.OK, "Пользователь прошел проверку. Операция прошла успешно");
            convertionResult = new ConvertionResult(from, resultMoney, convertionStatus);
        } else {
            ConvertionStatus convertionStatus = new ConvertionStatus(ConvertionStatus.ERROR, "Пользователь не прошел проверку. Операция не выполнилась");
            convertionResult = new ConvertionResult(null, null, convertionStatus);
        }
        System.out.println("Операция конвертации завершена...");
        return convertionResult;
    }

}
