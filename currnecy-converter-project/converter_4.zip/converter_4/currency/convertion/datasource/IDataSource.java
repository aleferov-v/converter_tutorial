package currency.convertion.datasource;

import currency.convertion.ConvertData;

import java.util.List;

/**
 * Общий интерфейс для всех источников данных
 */
public interface IDataSource {

    List<ConvertData> getConvertData();
}
