package currency;

import currency.convertion.ConvertData;
import currency.convertion.ConvertionResult;
import currency.convertion.convertors.CurrencyConverter;
import currency.convertion.datasource.FileDataSource;
import currency.convertion.datasource.IDataSource;
import currency.convertion.datasource.ProgrammDataSource;
import currency.person.Operator;
import currency.services.ManagmentService;
import currency.services.Printer;

import java.io.File;
import java.util.Scanner;

/**
 * Основной класс программы
 */
public class Converter {

    public static final String CLIENTS_FILE = "resources/clients.txt";

    /**
     * Конвертер
     */
    private CurrencyConverter converter;
    /**
     * Принтер для печати резальтата
     */
    private Printer printer;
    /**
     * Сервис по работе с персоналом
     */
    private ManagmentService managmentService;

    public Converter() {
        this.converter = new CurrencyConverter();
        this.printer = new Printer();
        this.managmentService = new ManagmentService();
    }

    /**
     * Метод выполняет конвертацию
     */
    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Укажите источник данных:");
        System.out.println("программа - 0");
        System.out.println("файл - 1");
        System.out.println("оба варианта - 2");
        int variant = scanner.nextInt();
        if (variant == 0) {
            processProgramm();
        } else if (variant == 1) {
            processFile();
        } else if (variant == 2) {
            processProgramm();
            processFile();
        } else {
            System.out.printf("Не подходит ни один из вариантов");
        }
    }

    private void processProgramm() {
        System.out.println(" =============== Работа конвертера с данными, полученными программно =============== ");
        Operator operator = managmentService.getTodayOperator();

        IDataSource dataSource = new ProgrammDataSource();
        ConvertData dataSourceConvertData = dataSource.getConvertData();

        ConvertionResult convertionResult = converter.convert(dataSourceConvertData, operator);
        if (convertionResult != null) {
            System.out.println("Печать результата:");
            printer.print(convertionResult);
        }
    }

    private void processFile() {
        System.out.println(" =============== Работа конвертера с данными, полученными из файла =============== ");
        Operator operator = managmentService.getTodayOperator();
        File clientsFile = new File(CLIENTS_FILE);

        IDataSource fileDataSource = new FileDataSource(clientsFile);
        ConvertData fileDataSourceConvertData = fileDataSource.getConvertData();

        ConvertionResult fileConvertionResult = converter.convert(fileDataSourceConvertData, operator);
        if (fileConvertionResult != null) {
            System.out.println("Печать результата:");
            printer.print(fileConvertionResult);
        } else {
            System.out.println("Не удалось получить данные из файла");
        }
    }
}
