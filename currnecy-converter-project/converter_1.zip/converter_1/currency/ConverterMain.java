package currency;

/**
 * Главный класс, начальная точка входа в программу
 */
public class ConverterMain {

    public static void main(String[] args) {
        Converter converter = new Converter();
        converter.run();
    }

}
