package currency.convertion;

/**
 * Результат конвертации. Содержит деньги в целевой валюте (если конвертация удалась) и статус конвертации
 */
public class ConvertionResult {

    /**
     * Деньги, из которых производилась конвертация
     */
    private final Money fromMoney;
    /**
     * Деньги, в которые производилась конвертация
     */
    private final Money toMoney;

    public ConvertionResult(Money fromMoney, Money toMoney) {
        this.fromMoney = fromMoney;
        this.toMoney = toMoney;
    }

    public Money getFromMoney() {
        return fromMoney;
    }

    public Money getToMoney() {
        return toMoney;
    }

}
