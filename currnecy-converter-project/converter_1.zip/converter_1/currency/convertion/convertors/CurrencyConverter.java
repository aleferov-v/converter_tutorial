package currency.convertion.convertors;

import currency.convertion.ConvertData;
import currency.convertion.ConvertionRequest;
import currency.convertion.ConvertionResult;
import currency.convertion.Money;
import currency.person.Operator;

/**
 * Класс, реализующий интерфейс конвертации валют
 */
public class CurrencyConverter implements ICurrencyConverter {

    @Override
    public ConvertionResult convert(ConvertData data, Operator operator) {
        ConvertionRequest request = operator.createRequest(data);
        double result = (request.getFrom().getAmount() * request.getFromRate()) / request.getToRate();
        Money resultMoney = new Money(request.getTo(), result);
        Money from = request.getFrom();
        return new ConvertionResult(from, resultMoney);
    }

}
