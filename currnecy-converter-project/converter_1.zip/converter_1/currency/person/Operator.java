package currency.person;

import currency.convertion.ConvertData;
import currency.convertion.ConvertionRequest;
import currency.convertion.Currency;
import currency.convertion.Money;

/**
 * Оператор, выполняющий операции, связанные с конвертацией
 */
public class Operator extends Person {

    /**
     * Номер внутреннего структурного подразделения
     */
    private String vsp;

    public Operator(String login, String vsp) {
        super(login);
        this.vsp = vsp;
    }

    /**
     * Создать заявку на конвертацию
     *
     * @data - данные для создания заявки
     * @return заявка
     */
    public ConvertionRequest createRequest(ConvertData data) {
        Money from = data.getFrom();
        Currency to = data.getTo();
        double fromRate = getCurrentRate(data.getFrom().getCurrency());
        double toRate = getCurrentRate(data.getTo());

        return new ConvertionRequest(from, to, fromRate, toRate);
    }

    /**
     * Получить текущую ставку для валюты. Если ни то ни другое не выбрано, то текущая ставка будет 1, т.е. курс 1 к 1
     *
     * @param currency - валюта
     * @return текущая ставка
     */
    public double getCurrentRate(Currency currency) {
        double result = 1;
        switch (currency) {
            case USD:
                result = 56.80;
                break;
            case EUR:
                result = 70.53;
                break;
        }
        return result;
    }
}
